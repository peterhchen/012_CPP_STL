// TOPIC: std::unordered_set
// 
// NOTES std::unordered_set:
// 0. Unordere Set is a associative container tjat contains set of unique objects.
// 1. Search, insertion, and removal have average constant-time complexity.
// 2. Internally, the elements are organized into buckets.
// 3. It uses hashing to insert elements into buckets.
// 4. This allows fast access to individual elements. Since once a hash is computed,
//    it refers to the exact bucket which the elemet is placed into.
//
// WHY UNORDERED SET?
// 0. maintain a collection of uniquw items with fast insertion and removel.

#include <iostream>
#include <unordered_set>
using namespace std;

int main() {
    unordered_set<int> uset = { 4, 1, 2, 3, 4, 2, 3 };
    auto search = uset.find(2);
    if (search != uset.end()) {
        cout << "Found " << (*search) << endl;
    }
    else {
        cout << "Not found" << endl;
    }
    cout << "e: uset" << endl;
    for (auto & e : uset) {
        cout << e << " ";
    }
    cout << endl;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
