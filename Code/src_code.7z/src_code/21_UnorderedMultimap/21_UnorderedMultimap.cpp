// TOPIC: std::unoredered_multimap in C++
// 
// NOTES:
// 0. Unordered multimap is an unordered associative container that supports equivalent keys (an unordered multimap
//    may contain multiple copies of key-value) and the associate values can have another type with the keys.
// 1. Search, insertion, and removal habe average constant0time complexity.
// 2. Internally, the elements are organized into buckets.
// 3. It uses hashing to insert elements into buckets.
// 4. This allows fast access to individual elements, since once a hash is computed, 
//    it refers to the next bucket where the element is placed into. 
//
// WHY UNORDERED_MULTIMAP
// 0. Maintain a colleciton of duplicate {key-=value} pais with fast insertion and removal.

#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
    unordered_multimap <int, char> ummap = { {5, 'd'} };
    ummap.insert({ 1, 'a' });
    ummap.insert(pair<int, char>(2, 'b'));
    ummap.insert(make_pair(3, 'c'));
    ummap.insert(make_pair(3, 'c'));
    cout << "e: ummap:" << endl;
    for (auto& e : ummap) {
        cout << e.first << " " << e.second << endl;
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
