// TOPIC: std::deque in C++!! (deque stands for Double Ended Queue)
//
// NOTES:
// 0. std::deque is an indexed sequence container.
// 1. It allows fast insertion at both beginning and end.
// 2. Unlike vector elements, deque are not stored contiguous.
// 3. It uses individual allocaed fixed size array, with additional bookkeeping, meaning index based access to deque
//    must perform two pointer dereference, but in vector, we only have one dereference.
// 4. The storage of a deque is automatically expaned and contracted as needed.
// 5. Expenson of deque is cjeapter thant expension of vector.
// 6. A deque holding just one element has to allocated its full internall array (e.e., 8 times the object size om
//    64-bit libdtdc++; 16 times the object siz or 4096 bytes, whichever is larger, on 64-bits libc++).

// TIME ECOMPLEXITY:
// Random access - constant O (1)
// Insertion or removal of elements at thhe end of beginnin - constant O(1)
// Insertion or removal of elements: linrar O(1).

#include <iostream>
#include <deque>
using namespace std;

void print(const deque<int>& dqu) {
    for (int num : dqu)
        cout << num << " " << endl;
}
int main() {
    {
        cout << "push deque : " << endl;
        deque<int> dqu = { 2, 3, 4 };
        dqu.push_front(1);
        dqu.push_back(5);
        print(dqu);
    }
    {
        cout << "pop deque : " << endl;
        deque<int> dqu = { 2, 3, 4 };
        dqu.pop_front();
        dqu.pop_back();
        print(dqu);
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
