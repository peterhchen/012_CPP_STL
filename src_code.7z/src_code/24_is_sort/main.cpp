// TOPIC: STL Algorithm is_sort
//
// NOTES:
// 0. Check if the elements in range [first, last) are sorted in non-descending order.
//
// TYPES:
// 1. Can check integral data types.
// 2. Can check user defined data types
// 3. Can check using a function object
// 4. Can check using lambda expression.
//
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main() {
    vector<int> Vec1 {5, 4, 5, 7, 3, 2, 8, 9, 1};
    sort(Vec1.begin(), Vec1.end());
    cout << "e1 : Vec1:" << endl;

    for (auto & e1 : Vec1) {
        cout << e1 << " ";
    }
    cout << endl;
    cout << "is_sorted: " << endl;
    cout << is_sorted(Vec1.begin(), Vec1.end());
    cout << endl << endl;

    vector<int> Vec2 {5, 4, 5, 7, 3, 2, 8, 9, 1};
    sort(Vec2.begin(), Vec2.end(), greater<int>());
    cout << "e2 : Vec2:" << endl;
    for (auto & e2 : Vec2) {
        cout << e2 << " ";
    }
    cout << endl;
    cout << "is_sorted: " << endl;
    cout << is_sorted(Vec2.begin(), Vec2.end());
    return 0;
}
