// TOPIC: STL Algorithm Sort
//
// NOTES:
// 0. In C++ STL, we have sort function which can sort in increasing and decreasing order.
// 1. Not only integral but user defined data can be sorted using this function.
// 2. Internally, it uses IntroSort which is combination of QuickSort, HeapSort, and InsertionSort.
// 3. By default, it uses QuickSort but if QuickSort is doing in fair partitioning and taking more than N*logN time,
//    it switches to HeapSort and when the array size becomes really small, it switches to InsertionSort.
// 4. We can use parallel execution policy for better performance
//

// TYPES:
// 1. Sorting integral data types.
// 2. Sorting user defined data types.
// 3. Sort using a function object.
// 4. Sort using lambda expression.

#include <iostream>
#include <algorithm>
#include <vector>
#include <execution>
using namespace std;
// 2. Sort with user defined data types
// NOTES:
// https://www.learncpp.com/cpp-tutorial/constructor-member-initializer-lists/
// class Something {
//   private:
//      int m_value1 {}; double m_value2 {};char m_value3 {};
//   public:
//      Something() : m_value1{ 1 }, m_value2{ 2.2 }, m_value3{ 'c' } // Initialize our member variables
//

// 2. Sort with user defined data types
class Point {
  public:
      int x;
      int y;
      Point(int x =0, int y = 0): x{x}, y{y} {}
      bool operator < (const Point & p1) {
          return (x+y) < (p1.x + p1.y);
      }
};

// 3. Sort using a function object
struct {
  // Note: C++ define "const" at the before the function body.
  bool operator() (int a, int b) const {
      return a < b;
  }
} customLess;

int main() {
    // 1. Sort with integral data types
    vector<int> Vec1{ 5, 4, 6, 7, 3, 2, 8, 9, 1 };
    std::sort (std::execution::par, Vec1.begin(), Vec1.end());
    cout << "e: Vec1: " << endl;
    for (auto& e : Vec1) {
        cout << e << " ";
    }
    cout << endl << endl;

    // 2. Sort with user defined data types
    vector<Point> Vec2 { {1, 2}, {3, 1}, {0, 1}};
    sort(Vec2.begin(), Vec2.end());
    cout << "e2: Vec2" << endl;
    for (auto & e2 : Vec2) {
        cout << e2.x << " " << e2.y << endl;
    }
    cout << endl << endl;

    // 3. Sort using a function object
    vector<int> Vec3{ 5, 4, 6, 7, 3, 2, 8, 9, 1 };
    std::sort (Vec3.begin(), Vec3.end(), customLess);
    cout << "e3 : Vec3: " << endl;
    for (auto& e3 : Vec3) {
        cout << e3 << " ";
    }
    cout << endl << endl;

    // 4. Sort using a lambda expression
    vector<int> Vec4{ 5, 4, 6, 7, 3, 2, 8, 9, 1 };
    std::sort (Vec4.begin(), Vec4.end(), [](int a, int b) { return a < b; } );
    cout << "e4: Vec4: " << endl;
    for (auto& e4 : Vec4) {
        cout << e4 << " ";
    }
    cout << endl << endl;
    // 5. Sort using a Descending Order
    vector<int> Vec5{ 5, 4, 6, 7, 3, 2, 8, 9, 1 };
    std::sort (Vec5.begin(), Vec5.end(), greater<int>() );
    cout << "e5: Vec5: " << endl;
    for (auto& e5 : Vec5) {
        cout << e5 << " ";
    }
    cout << endl << endl;
    // 6. Sort using a Ascending Order
    vector<int> Vec6{ 5, 4, 6, 7, 3, 2, 8, 9, 1 };
    std::sort (Vec6.begin(), Vec6.end(), less<int>() );
    cout << "e6: Vec6: " << endl;
    for (auto& e6 : Vec6) {
        cout << e6 << " ";
    }
    return 0;
}
