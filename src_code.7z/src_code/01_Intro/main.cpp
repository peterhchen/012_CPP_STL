// Topic: STL Introduction in C++

// Notes:
// 1. STL: Standard Template Library
// 2. It consists of three components
//   a. Container: To store the Data inside the Link List.
//   b. Iterator:
//   c. Algorithm
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
