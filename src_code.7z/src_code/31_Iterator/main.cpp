#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

int main() {
    // We have an vector, array, map, unordered collection, set, or unordered multiset
    // We want to fast loop through without index increment. Then, we need to iterator.
    vector <string> planets = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"};

    cout << "1. Index for looping:" << endl;    // 1: Index for loop.
    for (int i = 0; i < planets.size(); i++) {
        cout << planets[i] << " ";
    }
    cout << endl << endl;
    cout << "2. range-based for looping:" << endl; // 2: range-based for looping.
    for (const auto & e: planets) {
        cout << e << " ";
    }
    cout << endl << endl;
    cout << "3. Iterator looping:" << endl; // 3: iterator looping
    for (vector<string>::iterator it = planets.begin(); it != planets.end(); it++) {
        cout << *it << " ";
    }
    cout << endl << endl;
    return 0;
}
