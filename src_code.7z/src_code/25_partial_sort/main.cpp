// TOPIC: STL Algorithm partial_sort
//
// NOTES:
// 0. partial_sort rearrange elements, such that, the range [first, middle) contains the the sorted elements.
// 1. The order of equal elements is not guaranted to be preserved.
// 2. The order of remaining elements is unspecified.
//
// Look for overloads in cppreff  side.
#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
using namespace std;

int main(){
    vector<int> Vec1 {5, 7, 4, 8, 6, 1, 9, 0, 3};
    partial_sort(Vec1.begin(), Vec1.begin() + 4, Vec1.end());
    cout << "e1: Vec1" << endl;
    for (auto & e1: Vec1) {
        cout << e1 << " ";
    }
    cout << endl << endl;
    return 0;
}
