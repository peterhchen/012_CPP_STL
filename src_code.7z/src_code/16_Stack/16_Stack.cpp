// TOPIC: std::stack in C++
// 
// NOTES:
// 0. std::stack class is a container adapter that gives the programmer the functionality of a stack.
// 1. Internallly, it uses std::deque STL container.
// 2. It is LIFO (last-in, first-out) data structure.
// 3. std::stack allows to push (insert) and pop(remove) only from back.
// 
// FUNCTIONS PROVIDED:
// empty(): Return whether the stack is empty - Time Complexity: O(1).
// size(): Returns the size of the stack - Time Complexity: O (1).
// top(): Returns a reference to the top most element of the stack - Time Complexity: O(1)
// push(g): Add the element 'g' at the top of the stack - Time Complexity: O(1)
// pop(): Delete the top most element of the stack - Time Complexity: O(1)

#include <iostream>
#include <stack>
#include <vector>
using namespace std;

void print(stack<int> stk) {
    cout << "stk:" << endl;
    while(!stk.empty()) {
        // cout << stk.pop() << endl;
        // Note: We cannot remove and print.
        // Reference the data from top. 
        cout << stk.top() << endl;
        stk.pop(); // Remove from the back
    }
}

int main() {
    stack <int> stk;
    stk.push(1);
    stk.push(2);
    stk.push(3);
    print(stk);

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
