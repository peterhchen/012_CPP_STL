// TOPIC: std::pair in C++
// 
// SYNYAX:
// std::pair <T1, T2> obj;
// 
// Notes:
// 0. std:pair is a struct template that provides a way to store two heterogenous objects as a single unit.
// 1. map, multimap, unorder_map, or unorder_multimap can use pair to insert data into their structures. 

#include <iostream>
#include <vector>
using namespace std;

void print(pair<int, int>& obj) {
    cout << obj.first << " " << obj.second << endl;
}
int main() {
    {
        cout << "pair:" << endl;
        pair<int, int> obj(10, 20);
        print(obj);
        cout << endl;
    }
    {
        cout << "make_pair:" << endl;
        pair<int, int>obj = make_pair(10, 20);
        print(obj);
        cout << endl;
    }
    {
        cout << "vector(pair<>):" << endl;
        vector<pair<string, unsigned int>> list;
        list.push_back(make_pair("Peter", 65));
        list.push_back(make_pair("Irene", 57));
        list.push_back(make_pair("Jessica", 33));
        list.push_back(pair<string, int>("Jason", 31));
        list.push_back(pair<string, int>("Jasmine", 28));
        list.push_back(make_pair("Janathan", 22));
        for (auto& p : list) {
            cout << p.first << " " << p.second << endl;
        }

    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
