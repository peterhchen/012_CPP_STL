// TOPIC: STL Algorithm std::nth_element
//
// NOTES:
// 0. nth_element is a partial sorting algorithm that rearrange elements in [first, last), such that:
//    a. The element at the nth position is the one which should be at that position if we sort the list.
//    b. It does not sort the list. Just that all the elements, which precede the nth element are greater then it.
// 1. nth_element algorithm is implement using introselect.
//    a. introselect is a hybrid of quickselect and median of medians algorithm.
//       1. quickselet is used to find kth smallest number in an unsorted array.
//       2. median of medians is a median selection algorithm for better pivot select mainly used in quicksort.
//
// SUPPORTS TYPES:
// 1. Sorting integral data types.
// 2. Sorting user defined data types.
// 3. Sort using a function object.
// 4. Sort using lambda expression.
//
#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;

int main() {
    vector <int> v1{5, 6, 4, 3, 2, 6, 7, 9, 3};
    nth_element(v1.begin(), v1.begin()+ v1.size()/2, v1.end());
    cout << "The median element is " << v1[1] << endl;
    cout << endl;

    nth_element(v1.begin(), v1.begin()+ 1, v1.end(), greater<int>());
    cout << "The second largest element is " << v1[1] << endl;
    return 0;
}
