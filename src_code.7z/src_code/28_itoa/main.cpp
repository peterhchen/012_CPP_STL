// TOPICS: STL Algorithm std::itoa [integer (increase sequentially) filled into an array].
//
// NOTES:
// 0. Fills the range [first, last) with sequentially increasing values.
//    Starting with value and repeatly evaluating ++value.

#include <iostream>
#include <algorithm>
#include <list>
#include <numeric>
#include <vector>
using namespace std;

int main(){
    list<int> lst(10); // Give list 10 size)
    cout << "l: lst" << endl;
    for (auto & l: lst) {
        cout << l << " ";
    }
    cout << endl << endl;
    // l: lst
    // 0 0 0 0 0 0 0 0 0 0

    iota(lst.begin(), lst.end(), -4);
    cout << "e : lst" << endl;
    for (auto & e: lst) {
        cout << e << " ";
    }
    cout << endl << endl;
    // e : lst
    // -4 -3 -2 -1 0 1 2 3 4 5

    std::vector<std::list<int>::iterator> Vec(lst.size());
    //itoa(Vec.begin(), Vec.end(), lst.begin());

    cout << "e: Vec" << endl;
    for (auto & e: Vec) {
        cout << *e << endl;
    }
    cout << endl;
    return 0;
}
