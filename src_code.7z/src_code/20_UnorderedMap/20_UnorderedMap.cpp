// TOPIC: std:unordered_map in C++
// 
// NOTES:
// 0. std::unordered_map is an associative container that contains key-value pairs with unique keys.
// 1. Search, insetion, and removal habe average constant=time complexity.
// 2. Internalluy, the elelemts ae organized into buckets.
// 3. It uses hashing to insert elements into buckets.
// 4. This allows fast acces to indovidual elements, because after computing the hash of the value, it refers to
//    the exact bucket where the element is placed into.
//
// WHY UNORDERED_MAP
// 0. maintain a collecton of unique (key:value) pairs with fast insertion and removal.

#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
    unordered_map<int, char>umap = { {1, 'a'}, {2, 'b'} };
    // Access
    cout << "umap[1]: " << umap[1] << endl;
    cout << "umap[2]: " << umap[2] << endl;
    cout << endl;
    // Update
    umap[1] = 'c';
    
    // Iterate 
    cout << "e: umap" << endl;
    for (auto& e : umap) {
        cout << e.first << " " << e.second << endl;
    }
    cout << endl << endl;

    // Find
    auto result = umap.find(2);
    cout << "umap.find(2): " << endl;
    if (result != umap.end()) {
        cout << "Found: " << result->first << " " << result->second << endl;
    }
    else {
        cout << "Not found" << endl;
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
