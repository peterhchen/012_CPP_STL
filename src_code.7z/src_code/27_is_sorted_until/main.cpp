// TOPIC: STL Algorithm is_selected_until
// https://www.geeksforgeeks.org/stdis_sorted_until-in-cpp/
//
// NOTES:
// 0. Find how many elements are sorted in give range [first, last)
//
// SUPPORTS TYPES:
// 1. Sorting integral data types.
// 2. Sorting using defined data types.
// 3. Sort using a function object.
// 4. Sort using lambda expression.

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector <int> Vec1 { 1, 2, 3, 4, 2, 3, 6, 7, 8, 1};
    cout << "eVec1 : Vec1" << endl;
    for (auto & eVec1 : Vec1) {
        cout << eVec1 << " ";
    }
    cout << endl << endl;
    auto it = is_sorted_until(Vec1.begin(), Vec1.end());
    cout << "First unsorted element is *it: " << *it << endl;
    cout << endl;

    auto diff = distance(Vec1.begin(), it);
    cout << "The distance between first element (Vec1.begin() and unsorted element *it: ";
    cout << diff << endl;
    return 0;
}
