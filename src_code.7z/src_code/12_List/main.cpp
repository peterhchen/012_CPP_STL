// TOPIC: Lisyt In STL

// 1. This is double linked list what we knw anout from C progrmaming language.
// 2. List is sequence container that allow non-continguous memory allocation.
// 3. List is faster compared to other sequence container (vector, forward_list, deque) in terms of 
//    insertion, removal, and moving elements in any position provided we have the iterator to the position.
// 4. We should use tjis class instead of traditional double linked list because
//    a. Well tested.
//    b. Bunch of available function.
// 5. Few Available Operations:
//    operator =, assign, front, back, empty, size, max_size, clear, insert, emplace, push_back, pop_back,
//    push_front, pop_front, reverse, sort, merge, splice, unique, remove, remove_if, resize.

#include <iostream>
#include <list>
using namespace std;

int main() {
	list<int> list1 = { 5, 2, 4, 6, 2 };
	list<int> list2 = { 7, 6, 1, 9 };
	cout << "e1:" << endl;
	for (auto& e1 : list1)
		cout << e1 << " ";
	cout << endl;
	cout << "e2:" << endl;
	for (auto& e2: list2)
		cout << e2 << " ";
	cout << endl;

	list1.sort();
	list2.sort();
	cout << "sort1:" << endl;
	for (auto& sort1 : list1)
		cout << sort1 << " ";
	cout << endl;
	cout << "sort2:" << endl;
	for (auto& sort2 : list2)
		cout << sort2 << " ";
	cout << endl << endl;

	list1.merge(list2);
	cout << "merge1:" << endl;
	for (auto& merge1 : list1)
		cout << merge1 << " ";
	cout << endl;
	cout << "merge2:" << endl;
	for (auto& merge2 : list2)
		cout << merge2 << " ";
	cout << endl << endl;

	list<int> list5 = { 5, 2, 4, 6, 2 };
	list<int> list6 = { 7, 6, 1, 9 };
	cout << "e5:" << endl;
	for (auto& e5 : list5)
		cout << e5 << " ";
	cout << endl;
	cout << "e6:" << endl;
	for (auto& e6 : list6)
		cout << e6 << " ";
	cout << endl;
	list5.splice(list5.begin(), list6);
	cout << "splcie1:" << endl;
	for (auto& splice1 : list5)
		cout << splice1 << " ";
	cout << endl;
	cout << "splice2:" << endl;
	for (auto& splice2 : list6)
		cout << splice2 << " ";
	cout << endl << endl;
	return 0;
}
