// TOPIC: std::priority queue in C++ (Priority Queue)
//
// WHAT IS IT?
//
// NOTES:
// 0. std::priority_queue os a container adaptor that provides constant time lookup of the
//    largest OR smallest element.
// 1. By default, std::vector is the cotnainer used inside.
// 2. Cos of inertion and extractoin is logarithmic.
// 3. std::priority_queue is implemented using::make_heap, std::push_heap, std::pop_heap function.

#include <iostream>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

template<typename T> void print_queue(T& q) {
    while (!q.empty()) {
        cout << q.top() << " ";
        q.pop();
    }
    cout << endl;
}
int main() {
    {
        priority_queue<int> q;
        for (int e : {1, 8, 5, 6, 3, 4, 0, 9, 7, 2}) {
            q.push(e);
        }
        cout << "print_queue(q):" << endl;
        print_queue(q);
        cout << endl;
    }
    {
        priority_queue<int, vector<int>, greater<int> > q2;
        for (int e : {1, 8, 5, 6, 3, 4, 0, 9, 7, 2}) {
            q2.push(e);
        }
        cout << "print_queue(q2):" << endl;
        print_queue(q2);
        cout << endl;
    }
    // Using Lambda to compare elements.
    {
        auto cmp = [](int left, int right) { return (left) < (right);  };
        priority_queue<int, vector<int>, decltype(cmp)> q3(cmp);
        for (int e : {1, 8, 5, 6, 3, 4, 0, 9, 7, 2}) {
            q3.push(e);
        }
        cout << "print_queue(q3):" << endl;
        print_queue(q3);
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
