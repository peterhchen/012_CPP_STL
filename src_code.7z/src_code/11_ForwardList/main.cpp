// TOPIC: forward list in STL

// 1. This is single linked list what we know from C programming language.
// 2. WHy forward_list why not single_list?
// 3. We should use this class instead of traditional single linked list because
//    a. Well tested.
//    b. Bunch of available funciton.
// 4. Few Available Operations
//    operator =, assign, front, empty, max_size, clear, insert_after, emplace_after,
//    reverse, sort, merge, slice_after, i=unique, remove, remove_if, resize.
#include <iostream>
#include <forward_list>
using namespace std;

int main(){
    forward_list<int> list1 = {5, 4, 6, 2};
    forward_list<int> list2 = {7, 6, 1, 9};
    list1.insert_after (list1.begin(), 8);
    cout << "e:" << endl;
    for (auto& e: list1) {
        cout << e << " ";
    }
    cout << endl;
    list1.reverse();
    cout << "e1:" << endl;
    for (auto& e1: list1) {
        cout << e1 << " ";
    }
    cout << endl << endl;

    list1.sort();
    cout << "e1:" << endl;
    for (auto& e1: list1) {
        cout << e1 << " ";
    }
    cout << endl;
    list2.sort();
    cout << "e2:" << endl;
    for (auto& e2: list2) {
        cout << e2 << " ";
    }
    cout << endl;
    list1.merge(list2);
    cout << "e3:" << endl;
    for (auto& e3: list1) {
        cout << e3 << " ";
    }
    cout << endl << endl;

    forward_list<int> list5 = {5, 4, 6, 2};
    forward_list<int> list6 = {7, 6, 1, 9};
    list5.splice_after(list5.begin(), list6);
    cout << "e5:" << endl;
    for (auto& e5: list5) {
        cout << e5 << " ";
    }
    cout << endl << endl;

    cout << "Size of list5: " << distance(list5.begin(), list5.end()) << endl;
    cout << "Size of list6: " << distance(list6.begin(), list6.end()) << endl;
    return 0;
}
