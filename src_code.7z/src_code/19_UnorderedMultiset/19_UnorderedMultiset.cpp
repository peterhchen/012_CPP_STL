// TOPIC: std::unordered_multiset in C++
// 
// NOTES:
// 0. std::unordered_multiset is an associative container that contains set of possibly non-unique objects.
// 1. Search, insertion, and removal have average constant-time complexity.
// 2. Internally, tje elements are organized into buckets.
// 3. It uses hasing to insert elements into buckets.
// 4. This allows fast access to indovidual elments, because after comuting the hash of the value, it refers to
//    the exact bucket which the element is placed into.
//
// WHY UNORDERED_MULTISET?
// 0. maintain a collection of non-unique items with fast insertion and removal.

#include <iostream>
#include <unordered_set>
using namespace std;
int main() {
    unordered_multiset <int> umset = { 4, 1, 2, 3, 9, 4, 3, 2, 9, 8, 10 };
    auto search = umset.find(2);
    if (search != umset.end()) {
        cout << "Found " << (*search) << endl;
    } else {
        cout << "Not Found" << endl;
    }
    cout << "e: umset: " << endl;
    for (auto& e : umset) {
        cout << e << " ";
    }
    cout << endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
